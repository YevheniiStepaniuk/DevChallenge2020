﻿namespace UniqueArticles.Domain.Models
{
    public class CreateArticleRequest
    {
        public string Content { get; set; }
    }
}