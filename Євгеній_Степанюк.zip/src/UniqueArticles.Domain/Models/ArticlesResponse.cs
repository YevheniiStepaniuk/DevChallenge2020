﻿namespace UniqueArticles.Domain.Models
{
    public class ArticlesResponse
    {
        public ArticleResponse[] Articles { get; set; }
    }
}