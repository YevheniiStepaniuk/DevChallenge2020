﻿namespace UniqueArticles.Domain.Configuration
{
    public class UniqueArticlesOptions
    {
        public int SimilarityPercent { get; set; }
    }
}