﻿using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UniqueArticles.Domain.Models;

namespace UniqueArticles.Tests.Integration
{
    public static class HttpClientExtensions
    {
        public static async Task<ArticleResponse> CreateArticle(
            this HttpClient httpClient,
            CreateArticleRequest request)
        {
            return await Post<ArticleResponse>(httpClient, "articles", request);
        }

        public static async Task<ArticlesResponse> GetAllArticles(
            this HttpClient httpClient)
        {
            return await Get<ArticlesResponse>(httpClient, "articles");
        }

        public static async Task<ArticleResponse> GetArticle(
            this HttpClient httpClient, int articleId)
        {
            return await Get<ArticleResponse>(httpClient, $"articles/{articleId}");
        }

        public static async Task<ArticleGroupsResponse> GetDuplicateGroups(
            this HttpClient httpClient)
        {
            return await Get<ArticleGroupsResponse>(httpClient, $"articles/duplicate_groups");
        }

        public static async Task<TResponse> Get<TResponse>(
            this HttpClient httpClient,
            string url)
        {
            var response = await httpClient.GetAsync(url).ConfigureAwait(false);
            var responseString = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<TResponse>(responseString);

            return default;
        }

        public static async Task<TResponse> Post<TResponse>(
            this HttpClient httpClient,
            string url,
            object body)
        {
            var json = JsonConvert.SerializeObject(body);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync(url, content).ConfigureAwait(false);
            var responseString = await response.Content.ReadAsStringAsync();

            if (response.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<TResponse>(responseString);

            return default;
        }
    }
}