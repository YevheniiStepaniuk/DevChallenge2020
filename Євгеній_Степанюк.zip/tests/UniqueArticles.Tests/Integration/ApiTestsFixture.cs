﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NUnit.Framework;
using UniqueArticles.Infrastructure;

namespace UniqueArticles.Tests.Integration
{
    public class ApiTestsFixture
    {
        protected TestServer ApiServer { get; set; }
        protected HttpClient Sut { get; set; }
        protected ApplicationDbContext Context { get; set; }

        [OneTimeSetUp]
        public async Task OneTimeSetup()
        {
            var apiStartup = new WebHostBuilder()
                .ConfigureAppConfiguration((context, builder) =>
                {
                    var environment = context.HostingEnvironment;
                    builder
                        .AddEnvironmentVariables()
                        .SetBasePath(environment.ContentRootPath)
                        .AddJsonFile("appsettings.json", true, reloadOnChange: false);
                })
                .ConfigureLogging(builder => builder.AddConsole())
                .UseStartup<Startup>();

            ApiServer = new TestServer(apiStartup);

            Context = new DesignTimeDbContextFactory().CreateDbContext(Array.Empty<string>());
            await Context.Database.MigrateAsync();
        }

        [OneTimeTearDown]
        public async Task OneTimeTearDown()
        {
            try
            {
                ApiServer.Dispose();
                await Context.Database.EnsureDeletedAsync();
                await Context.DisposeAsync();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error during OneTimeTearDown");
                Console.WriteLine(e);
            }
        }

        [SetUp]
        public void SetUp()
        {
            Sut = CreateServiceClient();
        }

        [TearDown]
        public void TearDown()
        {
            Context.ArticleRelations.RemoveRange(Context.ArticleRelations);
            Context.Articles.RemoveRange(Context.Articles);
            Context.SaveChanges();
        }

        protected HttpClient CreateServiceClient()
        {
            return ApiServer.CreateClient();
        }
    }
}
