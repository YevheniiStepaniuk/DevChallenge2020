﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentAssertions;
using GenFu;
using NUnit.Framework;
using UniqueArticles.Domain.Models;

namespace UniqueArticles.Tests.Integration
{
    [TestFixture]
    public class ArticlesCrudTests: ApiTestsFixture
    {
        [Test]
        public async Task GetAll_Should_Return_All_Articles()
        {
            var articles = await GiveArticles(3);

            var expected = new ArticlesResponse {Articles = articles.ToArray()};
            var result = await Sut.GetAllArticles();

            expected.Should().BeEquivalentTo(result);
        }

        [Test]
        public async Task GetById_Should_Return_Article_With_Duplicates()
        {
            var request = A.New<CreateArticleRequest>();
            var article1 = await GivenArticleWithContent(request);
            var article2 = await GivenArticleWithContent(request);

            var result = await Sut.GetArticle(article1.Id);

            result.Should().NotBeNull();
            result.Content.Should().Be(request.Content);
            result.DuplicateArticleIds.Should().Contain(article2.Id);
        }

        [Test]
        public async Task GetById_Should_Not_Include_In_Duplicate_Not_Similar_Article()
        {
            var request = A.New<CreateArticleRequest>();
            var article1 = await GivenArticleWithContent(request);
            var article2 = await GivenArticleWithContent(request);
            var article3 = await GivenArticle();

            var result = await Sut.GetArticle(article1.Id);

            result.Should().NotBeNull();
            result.Content.Should().Be(request.Content);
            result.DuplicateArticleIds.Should().NotContain(article3.Id);
        }

        [Test]
        public async Task GetDuplicateGroups_Should_Return_Groups_Of_Duplicated_Articles()
        {
            var request1 = new CreateArticleRequest {Content = "hello world"};
            var request2 = new CreateArticleRequest {Content = "world hello"};

            var article1 = await GivenArticleWithContent(request1);
            var article2 = await GivenArticleWithContent(request2);

            var result = await Sut.GetDuplicateGroups();

            result.Should().NotBeNull();

            result.DuplicateGroups.Should().BeEquivalentTo(new object[] {new []{article1.Id, article2.Id}});
        }

        [Test]
        public async Task GetDuplicateGroups_Should_Not_Include_Single_Articles()
        {
            await GiveArticles(5);

            var result = await Sut.GetDuplicateGroups();

            result.Should().NotBeNull();
            result.DuplicateGroups.Should().BeEmpty();
        }

        protected async Task<List<ArticleResponse>> GiveArticles(int count = 1)
        {
            var requests = A.ListOf<CreateArticleRequest>(count);
            var articles = new List<ArticleResponse>();

            foreach (var createArticleRequest in requests)
            {
                var article = await Sut.CreateArticle(createArticleRequest);
                articles.Add(article);
            }

            return articles;
        }

        protected async Task<ArticleResponse> GivenArticle()
        {
            var articles = await GiveArticles();

            return articles.First();
        }

        protected async Task<ArticleResponse> GivenArticleWithContent(CreateArticleRequest request)
        {
            var article = await Sut.CreateArticle(request);

            return article;
        }
    }
}