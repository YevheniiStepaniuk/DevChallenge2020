﻿using System.Linq;
using FluentAssertions;
using NUnit.Framework;
using UniqueArticles.Domain;

namespace UniqueArticles.Tests.Unit
{
    [TestFixture]
    public class ArticlesSimilarityCalculatorCalculatorTests
    {
        [Test]
        [Timeout(3_000)]
        [TestCase(50)]
        [TestCase(100)]
        [TestCase(150)]
        public void CalculateSimilarityPercent_Should_Not_Exceed_Timeout(int count)
        {
            var row = string.Join(" ", Enumerable.Range(0, count).Select(s => TestData.Lorem48));
            
            var result = new ArticlesSimilarityCalculator().CalculateSimilarityPercent(row, row);

            result.Should().Be(100.0);
        }

        [Test]
        [TestCase("hello", "hello", 100)]
        [TestCase("hello word", "word hello", 100)]
        [TestCase("hello good perfect word", "word hello", 50)]
        [TestCase("hello good perfect word", "good hello word", 75)]
        [TestCase("It is a good day, today", "good a day today", 50)]
        [TestCase("hello", "word", 0)]
        public void CalculateSimilarityPercent_Should_Calculate_Percent(string row1, string row2, double percent)
        {
            var result = new ArticlesSimilarityCalculator().CalculateSimilarityPercent(row1, row2);

            result.Should().Be(percent);
        }
    }
}