How to run:
    docker-compose up
How to run tests:
    docker-compose -f ./docker-compose.test.yml up
How to change similarity percent for articles (default 95)
    - look into UniqueArticles__SimilarityPercent env variable in the docker-compose file

Swagger URL: 
- localhost:5000/swagger

